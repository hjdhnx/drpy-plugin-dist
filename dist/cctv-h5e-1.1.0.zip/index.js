// cctv-h5e 插件：央视频 tv.cctv.com hls_h5e 加密 TS → 标准 TS 解密代理（点播 + 频道直播）
// 解密核心：source/cctv_h5e_decrypt.hpp（GPLv3，基于 letr007/CCTVVideoDownloader，
// drpys 扩展 --stream/--init-new-mode），本文件为 HTTP 壳：拉分片 → spawn 平台二进制解密 → 回流。
// 点播 h5e（type25 新模式）与直播 cdrm（classic TEA 模式）同属一套算法，解密器通用。
//
// 端点：
//   GET /health                          存活检查
//   GET /resolve?guid=<cntv guid>        点播：视频信息 → hls_h5e_url，返回可交给 /m3u8 的地址
//   GET /m3u8?url=<h5e m3u8>&base=<enc>  拉 m3u8 并重写（master 重写 variant 行，media 重写 ts 行；
//                                        base 为回调前缀，不传则用本服务直连前缀）
//   GET /ts?u=<ts url>                   拉取分片；URL 含 /h5e/ 或 /cdrm 时解密，否则透传（仅代理 UA）
//   GET /live/channels                   直播：内置频道清单
//   GET /live/m3u8?ch=cctv1&q=td&base=<enc>  直播：auth-key 调 v3 接口 → hls_cdrm → 选清晰度档
//                                        → 重写 ts 行（base 回调前缀，不传则用本服务直连前缀）
//
// 运行环境：PORT（默认 7796）。零 npm 依赖。
import http from 'http';
import {spawn} from 'child_process';
import {existsSync} from 'fs';
import crypto from 'crypto';
import path from 'path';
import {fileURLToPath, pathToFileURL} from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 7796);
const UA = 'Lavf/60.10.100'; // cntv CDN 按 UA 放行（ffmpeg 形态），浏览器 UA 会 403
const REFERER = 'https://tv.cctv.com/';
const FETCH_TIMEOUT_MS = 30000;
const DECRYPT_TIMEOUT_MS = 60000;
const LIVE_API = 'https://vdnx.live.cntv.cn/api/v3/vdn/live';
const LIVE_AUTH_KEY_SECRET = 'a4220a71b31746908fa3e7fdd7a6852a';

// 直播频道清单（2026-08 实测 v3 接口均有 hls_cdrm 下发；cctv4k/8k 无流未收录）
export const LIVE_CHANNELS = [
    {ch: 'cctv1', name: 'CCTV-1 综合'},
    {ch: 'cctv2', name: 'CCTV-2 财经'},
    {ch: 'cctv3', name: 'CCTV-3 综艺'},
    {ch: 'cctv4', name: 'CCTV-4 中文国际'},
    {ch: 'cctv5', name: 'CCTV-5 体育'},
    {ch: 'cctv5plus', name: 'CCTV-5+ 体育赛事'},
    {ch: 'cctv6', name: 'CCTV-6 电影'},
    {ch: 'cctv7', name: 'CCTV-7 国防军事'},
    {ch: 'cctv8', name: 'CCTV-8 电视剧'},
    {ch: 'cctv9', name: 'CCTV-9 纪录'},
    {ch: 'cctv10', name: 'CCTV-10 科教'},
    {ch: 'cctv11', name: 'CCTV-11 戏曲'},
    {ch: 'cctv12', name: 'CCTV-12 社会与法'},
    {ch: 'cctv13', name: 'CCTV-13 新闻'},
    {ch: 'cctv15', name: 'CCTV-15 音乐'},
    {ch: 'cctv16', name: 'CCTV-16 奥林匹克'},
    {ch: 'cctv17', name: 'CCTV-17 农业农村'},
];

// v3 接口 auth-key：`time-number-md5(channel+time+number+secret)`（与网页播放器同款签名）
export function buildLiveAuthKey(channel, time = Date.now(), number = 100 + Math.floor(Math.random() * 901), secret = LIVE_AUTH_KEY_SECRET) {
    const md5 = crypto.createHash('md5').update(channel + time + number + secret).digest('hex');
    return `${time}-${number}-${md5}`;
}

// 解密二进制：按 platform-arch 选择（binaries 同名约定）
export function pickBinary(platform = process.platform, arch = process.arch) {
    const map = {
        'win32-x64': 'cctv-h5e-win.exe',
        'linux-x64': 'cctv-h5e-linux-x64',
        'linux-arm64': 'cctv-h5e-linux-arm64',
    };
    const file = map[`${platform}-${arch}`];
    if (!file) return null;
    const full = path.join(__dirname, file);
    return existsSync(full) ? full : null;
}

// SSRF 防护：目标 host 必须落在央视系域名后缀内
const ALLOWED_SUFFIXES = [
    '.cctv.cn', '.cntv.cn', '.cctv.com', '.cntv.vod.dnsv1.com', '.qcloudcdn.com',
    // 直播 CDN（hls_cdrm 每次下发可能命中不同厂商节点）
    '.kcdnvip.com', '.volcfcdn.com', '.bdydns.com', '.myqcloud.com', '.wscdns.com', '.myalicdn.com',
];
export function isAllowedUrl(rawUrl) {
    try {
        const u = new URL(rawUrl);
        if (u.protocol !== 'http:' && u.protocol !== 'https:') return false;
        const host = u.hostname.toLowerCase();
        return ALLOWED_SUFFIXES.some(s => host === s.slice(1) || host.endsWith(s));
    } catch {
        return false;
    }
}

// 上游 normalizeEncryptedPlaylistUrl：enc2 任意 CDN host 归一到 drm.cntv.vod.dnsv1.com
export function normalizeEncryptedUrl(url) {
    return url.replace(/^(https?:\/\/)[^/]+\/asp\/enc2\//, '$1drm.cntv.vod.dnsv1.com/asp/enc2/');
}

// videoinfoByGuid 返回里挑加密播放列表：hls_h5e_url → hls_enc_url → hls_enc2_url
export function pickEncryptedPlaylist(manifest) {
    if (!manifest) return '';
    return manifest.hls_h5e_url || manifest.hls_enc_url || manifest.hls_enc2_url || '';
}

// 加密流判定：点播 /asp/h5e/、直播 /cdrm 前缀流名（cdrmldcctvX_1*.m3u8 的分片路径继承）
// 其余（明文 TS）不能过解密器：classic 模式会破坏正常 NAL，只能透传
export function isEncryptedTsUrl(rawUrl) {
    return /\/h5e\//.test(rawUrl) || /cdrm/i.test(rawUrl);
}

// 从 TS buffer 探测视频 PID：PUSI 包 PES 头 stream_id 在 0xE0-0xEF（H.264 视频流）的包数最多者
export function detectVideoPid(buf) {
    const counts = {};
    for (let off = 0; off + 188 <= buf.length; off += 188) {
        if (buf[off] !== 0x47) continue;
        const pusi = (buf[off + 1] & 0x40) !== 0;
        if (!pusi) continue;
        const afc = (buf[off + 3] & 0x30) >> 4;
        const pi = afc === 1 ? 4 : afc === 2 || afc === 3 ? 5 + buf[off + 4] : -1;
        if (pi < 0 || pi + 3 > 188) continue;
        if (buf[off + pi] !== 0 || buf[off + pi + 1] !== 0 || buf[off + pi + 2] !== 1) continue;
        const streamId = buf[off + pi + 3];
        if (streamId < 0xe0 || streamId > 0xef) continue;
        const pid = ((buf[off + 1] & 0x1f) << 8) | buf[off + 2];
        counts[pid] = (counts[pid] || 0) + 1;
    }
    let best = 0, bestN = 0;
    for (const [pid, n] of Object.entries(counts)) {
        if (n > bestN) {
            best = Number(pid);
            bestN = n;
        }
    }
    return best || 0x100;
}

function fetchWithTimeout(url, ms = FETCH_TIMEOUT_MS) {
    return fetch(url, {
        headers: {'User-Agent': UA, Referer: REFERER},
        signal: AbortSignal.timeout(ms),
        redirect: 'follow',
    });
}

// cntv CDN 偶发瞬时 403/超时（地址刚签发需生效、节点切换），指数退避重试
async function fetchWithRetry(url, tries = 4) {
    let lastErr;
    for (let i = 0; i < tries; i++) {
        try {
            const r = await fetchWithTimeout(url);
            if (r.ok) return r;
            lastErr = new Error(`HTTP ${r.status}`);
        } catch (e) {
            lastErr = e;
        }
        if (i < tries - 1) await new Promise(res => setTimeout(res, 400 * Math.pow(2, i)));
    }
    throw new Error(`拉取失败(${tries}次): ${lastErr.message}`);
}

// 重写 m3u8：master 的 variant 行与 media 的 ts 行分别用不同回调前缀
// （m3u8Prefix 指向 /m3u8 类回调，tsPrefix 指向 /ts 类回调）；行地址 encode 后拼在前缀后
export function rewriteM3u8(text, playlistUrl, m3u8Prefix, tsPrefix) {
    const lines = text.split(/\r?\n/);
    const out = lines.map(line => {
        const t = line.trim();
        if (!t || t.startsWith('#')) return line;
        const abs = new URL(t, playlistUrl).href;
        const prefix = t.endsWith('.m3u8') ? m3u8Prefix : tsPrefix;
        return `${prefix}${encodeURIComponent(abs)}`;
    });
    return out.join('\n');
}

// spawn 平台二进制 --stream 解密。isH5e=false 时直接透传（明文分片不可过解密器，classic 模式会破坏数据）
function decryptTs(buf, isH5e, pid = 0x100) {
    return new Promise((resolve, reject) => {
        if (!isH5e) return resolve(buf);
        const bin = pickBinary();
        if (!bin) return reject(new Error(`不支持的平台 ${process.platform}-${process.arch} 或解密二进制缺失`));
        const args = ['--stream', '--pid', String(pid)];
        const proc = spawn(bin, args, {stdio: ['pipe', 'pipe', 'pipe']});
        const chunks = [];
        let stderr = '';
        const timer = setTimeout(() => {
            proc.kill();
            reject(new Error('解密超时'));
        }, DECRYPT_TIMEOUT_MS);
        proc.stdout.on('data', c => chunks.push(c));
        proc.stderr.on('data', c => {
            stderr += c;
        });
        proc.on('error', e => {
            clearTimeout(timer);
            reject(e);
        });
        proc.on('close', code => {
            clearTimeout(timer);
            if (code !== 0 && code !== 3) {
                return reject(new Error(`解密进程异常退出 code=${code}: ${stderr.trim().slice(0, 200)}`));
            }
            resolve(Buffer.concat(chunks));
        });
        proc.stdin.on('error', () => {});
        proc.stdin.end(buf);
    });
}

async function handleResolve(query) {
    const guid = (query.guid || '').trim();
    if (!/^[a-f0-9]{16,40}$/i.test(guid)) throw new Error('guid 参数无效');
    const r = await fetchWithTimeout(`https://vdn.apps.cntv.cn/api/getHttpVideoInfo.do?pid=${guid}`);
    const info = await r.json();
    const enc = normalizeEncryptedUrl(pickEncryptedPlaylist(info?.manifest));
    if (!enc) throw new Error(`视频信息获取失败或无 h5e 加密播放列表 (${info?.errcode || r.status})`);
    return {
        title: info.title,
        m3u8: `/m3u8?url=${encodeURIComponent(enc)}`,
        m3u8_full: `http://${query.__host}/m3u8?url=${encodeURIComponent(enc)}`,
        hls_h5e_url: enc,
        hls_url: info.hls_url || '',
    };
}

async function handleM3u8(query) {
    const raw = query.url || '';
    if (!raw) throw new Error('缺少 url 参数');
    const target = normalizeEncryptedUrl(raw);
    if (!isAllowedUrl(target)) throw new Error('目标地址不在央视域名白名单内');
    const r = await fetchWithRetry(target);
    const text = await r.text();
    if (!text.includes('#EXTM3U')) throw new Error(`上游返回非 m3u8（HTTP ${r.status}），可能链接过期`);
    // 回调前缀：ts/variant 行的重写目标（源 proxy 会传主服务 /proxy 回调前缀，两类行同前缀，
    // 源端按地址后缀分流 .m3u8→/m3u8、其余→/ts）；searchParams 已解码，勿再 decode
    const direct = `http://${query.__host}`;
    const m3u8Prefix = query.base ? query.base : `${direct}/m3u8?url=`;
    const tsPrefix = query.base ? query.base : `${direct}/ts?u=`;
    const rewritten = rewriteM3u8(text, target, m3u8Prefix, tsPrefix);
    return {text: rewritten};
}

async function handleTs(query) {
    const raw = query.u || query.url || '';
    const target = normalizeEncryptedUrl(raw);
    if (!isAllowedUrl(target)) throw new Error('目标地址不在央视域名白名单内');
    const r = await fetchWithRetry(target);
    if (!r.ok) throw new Error(`分片拉取失败 HTTP ${r.status}`);
    const buf = Buffer.from(await r.arrayBuffer());
    if (!isEncryptedTsUrl(target)) return buf;
    const pid = detectVideoPid(buf);
    return decryptTs(buf, true, pid);
}

// 直播：频道 → v3 接口（auth-key）→ hls_cdrm master → 选清晰度档 variant
// q: pd(1080)/td(720)/ud(576)/hd(480)，缺省 td；返回 media m3u8 的重写文本
async function handleLiveM3u8(query) {
    const ch = (query.ch || '').trim().toLowerCase();
    if (!/^[a-z0-9+]{3,12}$/.test(ch)) throw new Error('ch 参数无效');
    const q = (query.q || 'td').toLowerCase();
    const r = await fetch(`${LIVE_API}?channel=${ch}&vn=1`, {
        headers: {'auth-key': buildLiveAuthKey(ch), 'User-Agent': UA, Referer: REFERER},
        signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
    });
    const info = await r.json();
    const master = info?.manifest?.hls_cdrm;
    if (!master) throw new Error(`频道 ${ch} 无 cdrm 直播流 (${info?.status || r.status})`);
    if (!isAllowedUrl(master)) throw new Error('直播流地址不在央视域名白名单内');

    // master → 目标档位 variant。两种 CDN 形态：独立文件 `..._td.m3u8` 或同文件查询参数 `index.m3u8?BR=td`
    const masterText = await (await fetchWithRetry(master)).text();
    if (!masterText.includes('#EXT-X-STREAM-INF')) {
        // 上游直接给 media m3u8（无 master），按 media 处理
        return {text: rewriteLiveMedia(masterText, master, query)};
    }
    const lines = masterText.split(/\r?\n/).map(s => s.trim()).filter(Boolean);
    const want = new RegExp(`(?:[_-]${q}[._]|BR=${q})(?:m3u8|$)`, 'i');
    let variant = '', first = '';
    for (let i = 0; i < lines.length; i++) {
        if (!lines[i].startsWith('#EXT-X-STREAM-INF')) continue;
        const row = lines[i + 1] || '';
        if (!first) first = row;
        if (want.test(row)) {
            variant = row;
            break;
        }
    }
    if (!variant) variant = first;
    if (!variant) throw new Error('master m3u8 中未找到清晰度档');
    const variantUrl = new URL(variant, master).href;
    const mediaText = await (await fetchWithRetry(variantUrl)).text();
    if (!mediaText.includes('#EXTM3U')) throw new Error('variant 返回非 m3u8');
    return {text: rewriteLiveMedia(mediaText, variantUrl, query)};
}

// 直播 media m3u8 重写：ts 行全部走回调前缀（解密必须过插件）；滚动列表每次轮询实时拉实时重写
function rewriteLiveMedia(text, playlistUrl, query) {
    const direct = `http://${query.__host}`;
    const tsPrefix = query.base ? query.base : `${direct}/ts?u=`;
    const lines = text.split(/\r?\n/);
    return lines.map(line => {
        const t = line.trim();
        if (!t || t.startsWith('#')) return line;
        const abs = new URL(t, playlistUrl).href;
        return `${tsPrefix}${encodeURIComponent(abs)}`;
    }).join('\n');
}

const server = http.createServer(async (req, res) => {
    const u = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const query = Object.fromEntries(u.searchParams);
    query.__host = req.headers.host || `127.0.0.1:${PORT}`;
    const ok = (body, type = 'application/json; charset=utf-8', code = 200) => {
        res.writeHead(code, {'Content-Type': type});
        res.end(body);
    };
    const fail = (msg, code = 502) => ok(JSON.stringify({error: msg}), 'application/json; charset=utf-8', code);
    try {
        if (u.pathname === '/health') {
            const bin = pickBinary();
            return ok(JSON.stringify({ok: true, plugin: 'cctv-h5e', version: '1.1.0', binary: bin ? path.basename(bin) : null, ts: Date.now()}));
        }
        if (u.pathname === '/resolve') return ok(JSON.stringify(await handleResolve(query)));
        if (u.pathname === '/m3u8') return ok((await handleM3u8(query)).text, 'application/vnd.apple.mpegurl');
        if (u.pathname === '/ts') {
            const buf = await handleTs(query);
            res.writeHead(200, {'Content-Type': 'video/mp2t', 'Content-Length': buf.length});
            return res.end(buf);
        }
        if (u.pathname === '/live/channels') {
            return ok(JSON.stringify({channels: LIVE_CHANNELS.map(c => ({...c, m3u8: `/live/m3u8?ch=${c.ch}`}))}));
        }
        if (u.pathname === '/live/m3u8') return ok((await handleLiveM3u8(query)).text, 'application/vnd.apple.mpegurl');
        fail('not found', 404);
    } catch (e) {
        fail(e.message || String(e));
    }
});

if (import.meta.url === pathToFileURL(process.argv[1] || '').href) {
    server.listen(PORT, '0.0.0.0', () => {
        console.log(`[cctv-h5e] listening on :${PORT} (binary: ${path.basename(pickBinary() || 'N/A')})`);
    });
}
