# 红果短剧 TVBox 源

这是一个供个人电视播放使用的适配包：

- `hongguo.py`：TVBox 通用 Python 源，负责首页、分类、详情、搜索和选集。
- `bridge.py`：运行在同一局域网的 Windows 电脑上，负责应用接口签名和 CENC 解密。
- `config.json`：当前 MuMu 实例的设备参数。

## 使用

1. 双击 `启动播放桥.bat`，窗口保持运行。
2. 在 TVBox 配置中加入 Python 源：

```json
{
  "key": "hongguo",
  "name": "红果短剧",
  "type": 3,
  "api": "py_hongguo",
  "searchable": 1,
  "quickSearch": 1,
  "filterable": 0,
  "ext": "http://192.168.1.4:9979"
}
```

不同 TVBox 分支对 Python 源的加载写法略有区别：把 `hongguo.py` 放进该版本的
Python 源目录，并让 `api` 指向它即可。`ext` 必须是运行播放桥电脑的局域网地址。

浏览器访问 `http://192.168.1.4:9979/health`，出现 `{"ok":true,...}` 表示电视可连接。

## Ubuntu 部署

安装系统依赖：

```bash
sudo apt update
sudo apt install -y python3 python3-venv ffmpeg unzip
```

上传并解压本包，修改 `config.json` 中的 `public_url` 为服务器实际可访问地址，
然后运行：

```bash
chmod +x 启动播放桥_Ubuntu.sh
./启动播放桥_Ubuntu.sh
```

云服务器还需要在安全组和防火墙中放行 TCP 9979。TVBox 配置里的 `ext`
也要改成相同地址。建议仅允许自己家庭的公网 IP 访问该端口。

## 说明

红果的网页可直接取得剧目和全部选集 ID，但视频是客户端签名接口返回的 CENC
加密 MP4，所以仅靠 TVBox 内部的普通爬虫无法直接播放。本包把签名、解密和临时
MP4 缓存放在局域网播放桥中。缓存默认保留 1 小时。

签名与解密组件来自仓库内的 MIT 开源项目
`lingbol088-spec/short-drama-downloader`，其许可证位于
`short-drama-downloader-main/源码_开源版/LICENSE`。
