// cctv-h5e 插件：央视频 tv.cctv.com hls_h5e 加密 TS → 标准 TS 解密代理
// 解密核心：source/cctv_h5e_decrypt.hpp（GPLv3，基于 letr007/CCTVVideoDownloader，
// drpys 扩展 --stream/--init-new-mode），本文件为 HTTP 壳：拉分片 → spawn 平台二进制解密 → 回流。
//
// 端点：
//   GET /health                        存活检查
//   GET /resolve?guid=<cntv guid>      视频信息 → hls_h5e_url，返回可交给 /m3u8 的地址
//   GET /m3u8?url=<h5e m3u8>&base=<enc> 拉 m3u8 并重写（master 重写 variant 行，media 重写 ts 行；
//                                       base 为回调前缀，重写后 ts 行 = base + url=<enc(ts绝对地址)>，
//                                       不传 base 则用本服务 /ts?u= 前缀）
//   GET /ts?u=<ts url>                 拉取分片；URL 含 /h5e/ 时解密，否则透传（仅代理 UA）
//
// 运行环境：PORT（默认 7796）。零 npm 依赖。
import http from 'http';
import {spawn} from 'child_process';
import {existsSync} from 'fs';
import path from 'path';
import {fileURLToPath, pathToFileURL} from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 7796);
const UA = 'Lavf/60.10.100'; // cntv CDN 按 UA 放行（ffmpeg 形态），浏览器 UA 会 403
const REFERER = 'https://tv.cctv.com/';
const FETCH_TIMEOUT_MS = 30000;
const DECRYPT_TIMEOUT_MS = 60000;

// 解密二进制：按 platform-arch 选择（binaries 同名约定）
export function pickBinary(platform = process.platform, arch = process.arch) {
    const map = {
        'win32-x64': 'cctv-h5e-win.exe',
        'linux-x64': 'cctv-h5e-linux-x64',
        'linux-arm64': 'cctv-h5e-linux-arm64',
    };
    const file = map[`${platform}-${arch}`];
    if (!file) return null;
    const full = path.join(__dirname, file);
    return existsSync(full) ? full : null;
}

// SSRF 防护：目标 host 必须落在央视系域名后缀内
const ALLOWED_SUFFIXES = ['.cctv.cn', '.cntv.cn', '.cctv.com', '.cntv.vod.dnsv1.com', '.qcloudcdn.com'];
export function isAllowedUrl(rawUrl) {
    try {
        const u = new URL(rawUrl);
        if (u.protocol !== 'http:' && u.protocol !== 'https:') return false;
        const host = u.hostname.toLowerCase();
        return ALLOWED_SUFFIXES.some(s => host === s.slice(1) || host.endsWith(s));
    } catch {
        return false;
    }
}

// 上游 normalizeEncryptedPlaylistUrl：enc2 任意 CDN host 归一到 drm.cntv.vod.dnsv1.com
export function normalizeEncryptedUrl(url) {
    return url.replace(/^(https?:\/\/)[^/]+\/asp\/enc2\//, '$1drm.cntv.vod.dnsv1.com/asp/enc2/');
}

// videoinfoByGuid 返回里挑加密播放列表：hls_h5e_url → hls_enc_url → hls_enc2_url
export function pickEncryptedPlaylist(manifest) {
    if (!manifest) return '';
    return manifest.hls_h5e_url || manifest.hls_enc_url || manifest.hls_enc2_url || '';
}

function fetchWithTimeout(url, ms = FETCH_TIMEOUT_MS) {
    return fetch(url, {
        headers: {'User-Agent': UA, Referer: REFERER},
        signal: AbortSignal.timeout(ms),
        redirect: 'follow',
    });
}

// cntv CDN 偶发瞬时 403/超时（地址刚签发、节点切换），自动重试
async function fetchWithRetry(url, tries = 3) {
    let lastErr;
    for (let i = 0; i < tries; i++) {
        try {
            const r = await fetchWithTimeout(url);
            if (r.ok) return r;
            lastErr = new Error(`HTTP ${r.status}`);
        } catch (e) {
            lastErr = e;
        }
        if (i < tries - 1) await new Promise(res => setTimeout(res, 500 * (i + 1)));
    }
    throw new Error(`拉取失败(${tries}次): ${lastErr.message}`);
}

// 重写 m3u8：master 的 variant 行与 media 的 ts 行分别用不同回调前缀
// （m3u8Prefix 指向 /m3u8 类回调，tsPrefix 指向 /ts 类回调）；行地址 encode 后拼在前缀后
export function rewriteM3u8(text, playlistUrl, m3u8Prefix, tsPrefix) {
    const lines = text.split(/\r?\n/);
    const out = lines.map(line => {
        const t = line.trim();
        if (!t || t.startsWith('#')) return line;
        const abs = new URL(t, playlistUrl).href;
        const prefix = t.endsWith('.m3u8') ? m3u8Prefix : tsPrefix;
        return `${prefix}${encodeURIComponent(abs)}`;
    });
    return out.join('\n');
}

// spawn 平台二进制 --stream 解密。isH5e=false 时直接透传（明文分片不可过解密器，classic 模式会破坏数据）
function decryptTs(buf, isH5e) {
    return new Promise((resolve, reject) => {
        if (!isH5e) return resolve(buf);
        const bin = pickBinary();
        if (!bin) return reject(new Error(`不支持的平台 ${process.platform}-${process.arch} 或解密二进制缺失`));
        const proc = spawn(bin, ['--stream'], {stdio: ['pipe', 'pipe', 'pipe']});
        const chunks = [];
        let stderr = '';
        const timer = setTimeout(() => {
            proc.kill();
            reject(new Error('解密超时'));
        }, DECRYPT_TIMEOUT_MS);
        proc.stdout.on('data', c => chunks.push(c));
        proc.stderr.on('data', c => {
            stderr += c;
        });
        proc.on('error', e => {
            clearTimeout(timer);
            reject(e);
        });
        proc.on('close', code => {
            clearTimeout(timer);
            if (code !== 0 && code !== 3) {
                return reject(new Error(`解密进程异常退出 code=${code}: ${stderr.trim().slice(0, 200)}`));
            }
            resolve(Buffer.concat(chunks));
        });
        proc.stdin.on('error', () => {});
        proc.stdin.end(buf);
    });
}

async function handleResolve(query) {
    const guid = (query.guid || '').trim();
    if (!/^[a-f0-9]{16,40}$/i.test(guid)) throw new Error('guid 参数无效');
    const r = await fetchWithTimeout(`https://vdn.apps.cntv.cn/api/getHttpVideoInfo.do?pid=${guid}`);
    const info = await r.json();
    const enc = normalizeEncryptedUrl(pickEncryptedPlaylist(info?.manifest));
    if (!enc) throw new Error(`视频信息获取失败或无 h5e 加密播放列表 (${info?.errcode || r.status})`);
    return {
        title: info.title,
        m3u8: `/m3u8?url=${encodeURIComponent(enc)}`,
        m3u8_full: `http://${query.__host}/m3u8?url=${encodeURIComponent(enc)}`,
        hls_h5e_url: enc,
        hls_url: info.hls_url || '',
    };
}

async function handleM3u8(query) {
    const raw = query.url || '';
    if (!raw) throw new Error('缺少 url 参数');
    const target = normalizeEncryptedUrl(raw);
    if (!isAllowedUrl(target)) throw new Error('目标地址不在央视域名白名单内');
    const r = await fetchWithRetry(target);
    const text = await r.text();
    if (!text.includes('#EXTM3U')) throw new Error(`上游返回非 m3u8（HTTP ${r.status}），可能链接过期`);
    // 回调前缀：ts/variant 行的重写目标（源 proxy 会传主服务 /proxy 回调前缀，两类行同前缀，
    // 源端按地址后缀分流 .m3u8→/m3u8、其余→/ts）；searchParams 已解码，勿再 decode
    const direct = `http://${query.__host}`;
    const m3u8Prefix = query.base ? query.base : `${direct}/m3u8?url=`;
    const tsPrefix = query.base ? query.base : `${direct}/ts?u=`;
    const rewritten = rewriteM3u8(text, target, m3u8Prefix, tsPrefix);
    return {text: rewritten};
}

async function handleTs(query) {
    const raw = query.u || query.url || '';
    const target = normalizeEncryptedUrl(raw);
    if (!isAllowedUrl(target)) throw new Error('目标地址不在央视域名白名单内');
    const r = await fetchWithRetry(target);
    if (!r.ok) throw new Error(`分片拉取失败 HTTP ${r.status}`);
    const buf = Buffer.from(await r.arrayBuffer());
    const isH5e = target.includes('/h5e/');
    return decryptTs(buf, isH5e);
}

const server = http.createServer(async (req, res) => {
    const u = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
    const query = Object.fromEntries(u.searchParams);
    query.__host = req.headers.host || `127.0.0.1:${PORT}`;
    const ok = (body, type = 'application/json; charset=utf-8', code = 200) => {
        res.writeHead(code, {'Content-Type': type});
        res.end(body);
    };
    const fail = (msg, code = 502) => ok(JSON.stringify({error: msg}), 'application/json; charset=utf-8', code);
    try {
        if (u.pathname === '/health') {
            const bin = pickBinary();
            return ok(JSON.stringify({ok: true, plugin: 'cctv-h5e', binary: bin ? path.basename(bin) : null, ts: Date.now()}));
        }
        if (u.pathname === '/resolve') return ok(JSON.stringify(await handleResolve(query)));
        if (u.pathname === '/m3u8') return ok((await handleM3u8(query)).text, 'application/vnd.apple.mpegurl');
        if (u.pathname === '/ts') {
            const buf = await handleTs(query);
            res.writeHead(200, {'Content-Type': 'video/mp2t', 'Content-Length': buf.length});
            return res.end(buf);
        }
        fail('not found', 404);
    } catch (e) {
        fail(e.message || String(e));
    }
});

if (import.meta.url === pathToFileURL(process.argv[1] || '').href) {
    server.listen(PORT, '0.0.0.0', () => {
        console.log(`[cctv-h5e] listening on :${PORT} (binary: ${path.basename(pickBinary() || 'N/A')})`);
    });
}
