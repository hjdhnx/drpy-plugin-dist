# -*- coding: utf-8 -*-
"""红果 TVBox 局域网播放桥。只监听本机局域网，解析并缓存已解密 MP4。"""
import importlib.util
import json
import os
import sys
import threading
import time
from pathlib import Path

from flask import Flask, jsonify, redirect, request, send_from_directory


ROOT = Path(__file__).resolve().parent
VENDOR = ROOT / "short-drama-downloader-main" / "源码_开源版"
PARSER_FILE = VENDOR / "1.py"
CONFIG_FILE = ROOT / "config.json"

if not PARSER_FILE.exists():
    raise RuntimeError("缺少解析组件：" + str(PARSER_FILE))

config = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
os.environ.setdefault("DUANJU_DEVICE_ID", str(config.get("device_id", "")))
os.environ.setdefault("DUANJU_INSTALL_ID", str(config.get("install_id", "")))
os.environ.setdefault("DUANJU_PLATFORM", str(config.get("platform", "android")))


def _resolve_port():
    """端口优先级：--port 命令行参数 > 环境变量 APP_PORT > config.json port > 9979。

    插件托管场景两种配置方式等价：
    - .plugins.js 的 params 写 `--port 8888`
    - .plugins.js 的 env 写 {"APP_PORT": "8888"}
    最终端口统一写回 os.environ["APP_PORT"]，保证解析组件（1.py）与 Flask 主端口一致。
    """
    argv = sys.argv
    if "--port" in argv:
        idx = argv.index("--port")
        if idx + 1 < len(argv):
            return str(int(argv[idx + 1]))
    for token in argv:
        if token.startswith("--port="):
            return str(int(token.split("=", 1)[1]))
    env_port = os.environ.get("APP_PORT", "").strip()
    if env_port.isdigit():
        return env_port
    return str(int(config.get("port", 9979)))


PORT = _resolve_port()
os.environ["APP_PORT"] = PORT  # 覆盖写回：解析组件与 Flask 主端口强制一致
os.environ.setdefault("OPEN_BROWSER", "0")

spec = importlib.util.spec_from_file_location("hongguo_parser", str(PARSER_FILE))
parser = importlib.util.module_from_spec(spec)
spec.loader.exec_module(parser)

# 让解析组件将文件写进本项目的 src，避免依赖第三方目录布局。
parser.get_runtime_base_dir = lambda: ROOT
parser.VIDEO_TTL_SECONDS = int(config.get("cache_seconds", 3600))
public_url = str(
    config.get("public_url")
    or ("http://192.168.1.4:%s" % PORT)
).rstrip("/")
# 解密任务在线程池中运行，不能在线程里访问 Flask 的 request 代理。
parser.get_current_domain = lambda request=None: public_url

app = Flask(__name__)


@app.after_request
def cors(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Range, Content-Type"
    response.headers["Access-Control-Expose-Headers"] = (
        "Content-Length, Content-Range, Accept-Ranges"
    )
    return response


@app.route("/health")
def health():
    aes_bench = ""
    crypto_path = ""
    try:
        from Crypto.Cipher import AES
        import Crypto
        crypto_path = Crypto.__file__
        cipher = AES.new(b"0" * 16, AES.MODE_CTR, nonce=b"", initial_value=b"0" * 16)
        t0 = time.perf_counter()
        cipher.decrypt(b"A" * (1024 * 1024))
        aes_bench = "%.4fs/MB" % (time.perf_counter() - t0)
    except Exception as exc:
        aes_bench = "error: " + str(exc)
    py_env = {k: v for k, v in os.environ.items() if k != "Path"}
    return jsonify({
        "ok": True,
        "service": "hongguo-tvbox-bridge",
        "python": sys.executable,
        "cpu": os.cpu_count(),
        "affinity": len(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else "n/a",
        "aes_bench": aes_bench,
        "crypto_path": crypto_path,
        "env": py_env,
    })


# 同 vid 解密互斥 + 结果缓存：解密是 GIL 密集的纯 CPU 任务，壳子超时重试会造成
# 并发全量解密互相拖慢（恶性循环直到全部超时）；合并为一次解密后，重试方等待数秒即命中缓存
_vid_locks = {}
_resolve_cache = {}
_RESOLVE_TTL = 300  # 秒；解密文件本体 TTL 为 config cache_seconds（默认 3600），远大于此
_guard = threading.Lock()


def _resolve_cached(vid, flask_request):
    with _guard:
        if vid not in _vid_locks:
            _vid_locks[vid] = threading.Lock()
        if len(_resolve_cache) > 1000:  # 防dict无限增长：只留未过期条目
            now = time.time()
            for k in [k for k, v in _resolve_cache.items() if now - v[0] > _RESOLVE_TTL]:
                _resolve_cache.pop(k, None)
    lock = _vid_locks[vid]
    with lock:
        hit = _resolve_cache.get(vid)
        if hit and time.time() - hit[0] < _RESOLVE_TTL:
            return hit[1]
        result = parser.handle_video_request(vid, flask_request, max_retries=3)
        _resolve_cache[vid] = (time.time(), result)
        return result


@app.route("/play")
def play():
    vid = request.args.get("vid", "").strip()
    if not vid.isdigit():
        return jsonify({"error": "vid 参数无效"}), 400
    try:
        result = _resolve_cached(vid, request)
        media_url = str(result.get("url") or "")
        if not media_url:
            return jsonify({"error": "没有取得播放地址"}), 502
        return redirect(media_url, code=302)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 502


@app.route("/resolve")
def resolve():
    vid = request.args.get("vid", "").strip()
    if not vid.isdigit():
        return jsonify({"error": "vid 参数无效"}), 400
    try:
        return jsonify(_resolve_cached(vid, request))
    except Exception as exc:
        return jsonify({"error": str(exc)}), 502


@app.route("/src/<path:filename>")
def media(filename):
    return send_from_directory(str(ROOT / "src"), filename, conditional=True)


if __name__ == "__main__":
    print("红果 TVBox 播放桥：http://0.0.0.0:%s" % PORT)
    app.run(host="0.0.0.0", port=int(PORT), threaded=True, debug=False)
