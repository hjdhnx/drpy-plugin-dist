# -*- coding: utf-8 -*-
"""红果 TVBox 局域网播放桥。只监听本机局域网，解析并缓存已解密 MP4。"""
import importlib.util
import json
import os
import sys
from pathlib import Path

from flask import Flask, jsonify, redirect, request, send_from_directory


ROOT = Path(__file__).resolve().parent
VENDOR = ROOT / "short-drama-downloader-main" / "源码_开源版"
PARSER_FILE = VENDOR / "1.py"
CONFIG_FILE = ROOT / "config.json"

if not PARSER_FILE.exists():
    raise RuntimeError("缺少解析组件：" + str(PARSER_FILE))

config = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
os.environ.setdefault("DUANJU_DEVICE_ID", str(config.get("device_id", "")))
os.environ.setdefault("DUANJU_INSTALL_ID", str(config.get("install_id", "")))
os.environ.setdefault("DUANJU_PLATFORM", str(config.get("platform", "android")))


def _resolve_port():
    """端口优先级：--port 命令行参数 > 环境变量 APP_PORT > config.json port > 9979。

    插件托管场景两种配置方式等价：
    - .plugins.js 的 params 写 `--port 8888`
    - .plugins.js 的 env 写 {"APP_PORT": "8888"}
    最终端口统一写回 os.environ["APP_PORT"]，保证解析组件（1.py）与 Flask 主端口一致。
    """
    argv = sys.argv
    if "--port" in argv:
        idx = argv.index("--port")
        if idx + 1 < len(argv):
            return str(int(argv[idx + 1]))
    for token in argv:
        if token.startswith("--port="):
            return str(int(token.split("=", 1)[1]))
    env_port = os.environ.get("APP_PORT", "").strip()
    if env_port.isdigit():
        return env_port
    return str(int(config.get("port", 9979)))


PORT = _resolve_port()
os.environ["APP_PORT"] = PORT  # 覆盖写回：解析组件与 Flask 主端口强制一致
os.environ.setdefault("OPEN_BROWSER", "0")

spec = importlib.util.spec_from_file_location("hongguo_parser", str(PARSER_FILE))
parser = importlib.util.module_from_spec(spec)
spec.loader.exec_module(parser)

# 让解析组件将文件写进本项目的 src，避免依赖第三方目录布局。
parser.get_runtime_base_dir = lambda: ROOT
parser.VIDEO_TTL_SECONDS = int(config.get("cache_seconds", 3600))
public_url = str(
    config.get("public_url")
    or ("http://192.168.1.4:%s" % PORT)
).rstrip("/")
# 解密任务在线程池中运行，不能在线程里访问 Flask 的 request 代理。
parser.get_current_domain = lambda request=None: public_url

app = Flask(__name__)


@app.after_request
def cors(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Range, Content-Type"
    response.headers["Access-Control-Expose-Headers"] = (
        "Content-Length, Content-Range, Accept-Ranges"
    )
    return response


@app.route("/health")
def health():
    return jsonify({
        "ok": True,
        "service": "hongguo-tvbox-bridge",
    })


@app.route("/play")
def play():
    vid = request.args.get("vid", "").strip()
    if not vid.isdigit():
        return jsonify({"error": "vid 参数无效"}), 400
    try:
        result = parser.handle_video_request(vid, request, max_retries=3)
        media_url = str(result.get("url") or "")
        if not media_url:
            return jsonify({"error": "没有取得播放地址"}), 502
        return redirect(media_url, code=302)
    except Exception as exc:
        return jsonify({"error": str(exc)}), 502


@app.route("/resolve")
def resolve():
    vid = request.args.get("vid", "").strip()
    try:
        return jsonify(parser.handle_video_request(vid, request, max_retries=3))
    except Exception as exc:
        return jsonify({"error": str(exc)}), 502


@app.route("/src/<path:filename>")
def media(filename):
    return send_from_directory(str(ROOT / "src"), filename, conditional=True)


if __name__ == "__main__":
    print("红果 TVBox 播放桥：http://0.0.0.0:%s" % PORT)
    app.run(host="0.0.0.0", port=int(PORT), threaded=True, debug=False)
