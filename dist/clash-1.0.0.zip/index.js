import { spawn } from 'node:child_process';
import path from 'node:path';
import fs from 'node:fs';
import net from 'node:net';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// 所有日志走 stderr（同步写入，process.exit 不会截断，确保 pluginManager 总能收到）
function log(msg) { process.stderr.write(`[clash] ${msg}\n`); }

// 按平台+架构选内核二进制，找不到时回退到通用名
const ARCH_MAP = {
    win32: { x64: 'clash-win.exe', arm64: 'clash-win-arm64.exe' },
    linux: { x64: 'clash-linux-amd64', arm64: 'clash-linux-arm64', arm: 'clash-linux-armv7' },
    darwin: { x64: 'clash-darwin', arm64: 'clash-darwin-arm64' },
};
const GENERIC_MAP = { win32: 'clash-win.exe', linux: 'clash-linux', darwin: 'clash-darwin' };

const archBins = ARCH_MAP[process.platform];
if (!archBins) {
    log(`不支持的平台: ${process.platform}`);
    process.exit(1);
}
let binName = archBins[process.arch];
if (!binName) {
    log(`不支持的架构: ${process.platform}/${process.arch}`);
    process.exit(1);
}
let bin = path.join(__dirname, binName);
if (!fs.existsSync(bin)) {
    const generic = GENERIC_MAP[process.platform];
    if (generic && generic !== binName && fs.existsSync(path.join(__dirname, generic))) {
        log(`⚠️ ${binName} 不存在，回退到通用二进制 ${generic}`);
        binName = generic;
        bin = path.join(__dirname, binName);
    }
}
if (!fs.existsSync(bin)) {
    log(`内核二进制不存在: ${bin}`);
    process.exit(1);
}

const configPath = path.join(__dirname, 'config.yaml');
const args = ['-d', __dirname, '-f', configPath];
log(`正在启动 mihomo...`);
log(`内核: ${binName} | 平台: ${process.platform}/${process.arch} | 工作目录: ${__dirname}`);
log(`配置: ${configPath}`);

// 运行时确保二进制有执行权限（避免 EACCES，尤其是从其他环境同步过来丢失 x 位的情况）
try {
    fs.chmodSync(bin, 0o755);
} catch (e) {
    log(`⚠️ chmod ${binName} 失败: ${e.message}`);
}

const child = spawn(bin, args, {
    cwd: __dirname,
    stdio: ['ignore', 'pipe', 'pipe'],
});

// 捕获 mihomo 输出，逐行转发到 stderr；缓存 stderr 用于退出诊断
const stderrLines = [];
const MAX_STDERR = 50;
function emit(stream, isErr) {
    stream.on('data', (d) => {
        d.toString().split('\n').forEach((line) => {
            if (!line.trim()) return;
            log(line);
            if (isErr) {
                stderrLines.push(line);
                if (stderrLines.length > MAX_STDERR) stderrLines.shift();
            }
        });
    });
}
emit(child.stdout, false);
emit(child.stderr, true);

// 端口探测
function probePort(port, host) {
    return new Promise((resolve) => {
        const sock = net.connect({ port, host, timeout: 2000 });
        sock.on('connect', () => { sock.destroy(); resolve(true); });
        sock.on('error', () => resolve(false));
        sock.on('timeout', () => { sock.destroy(); resolve(false); });
    });
}
async function waitForPort(port, host, attempts, intervalMs) {
    for (let i = 0; i < attempts; i++) {
        if (await probePort(port, host)) return true;
        await new Promise((r) => setTimeout(r, intervalMs));
    }
    return false;
}

// 启动后轮询探测 9090/7890 是否就绪
setTimeout(async () => {
    const ok9090 = await waitForPort(9090, '127.0.0.1', 6, 2000);
    if (ok9090) {
        log(`✅ 9090 控制端口已就绪，管理面板: /clash`);
    } else {
        log(`⚠️ 9090 端口未就绪，mihomo 可能启动失败（请看上方 [clash] 日志）`);
    }
    const ok7890 = await waitForPort(7890, '127.0.0.1', 6, 2000);
    if (ok7890) {
        log(`✅ 7890 混合代理端口已就绪`);
    } else {
        log(`⚠️ 7890 代理端口未就绪，爬虫走代理会失败`);
    }
}, 3000);

child.on('error', (err) => {
    log(`❌ 启动失败: ${err.message}`);
    if (err.code === 'EACCES') {
        log(`提示: 无执行权限，请执行 chmod +x ${binName}`);
    } else if (err.code === 'ENOENT') {
        log(`提示: 二进制不存在: ${bin}`);
    }
    process.exit(1);
});

child.on('exit', (code, signal) => {
    log(`mihomo 退出 code=${code} signal=${signal}`);
    if (code !== 0 && code !== null) {
        log(`❌ 异常退出，最后 ${Math.min(10, stderrLines.length)} 行日志:`);
        stderrLines.slice(-10).forEach((line) => log(`  ${line}`));
    }
    if (signal) {
        try { process.kill(process.pid, signal); } catch (_) { process.exit(1); }
    } else {
        process.exit(code ?? 0);
    }
});

for (const sig of ['SIGTERM', 'SIGINT']) {
    process.on(sig, () => {
        log(`收到 ${sig}，停止 mihomo...`);
        try { child.kill(sig); } catch (_) {}
    });
}
