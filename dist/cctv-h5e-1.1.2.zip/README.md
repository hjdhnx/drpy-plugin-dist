# cctv-h5e（drpyS 插件）

央视频 tv.cctv.com 点播 `hls_h5e` 加密 TS 与频道直播 `cdrm` 加密 TS → 标准 MPEG-TS 的解密代理服务。

## 解密核心来源与修改

- 上游：https://github.com/letr007/CCTVVideoDownloader （GPLv3）
- 核心文件：`source/cctv_h5e_decrypt.hpp`（单头文件、纯算法、密钥内嵌 NAL 无需外部取 key）
- drpys 修改（算法未动，仅 CLI 层）：
  - 新增 `--stream`：stdin 全读 → 解密 → stdout，供插件管道调用（免临时文件）
  - 新增 `--init-new-mode 0|1`：跨分片 new_mode 状态兜底（实测每个分片自带 type25 使能 NAL，正常无需传）
  - stderr 机器可读统计行 `H5E new_mode=<0|1> nals=<N>`，退出码 0=有 NAL / 3=无视频 NAL
- GPLv3 合规：二进制分发附带 LICENSE 与对应完整源码（`source/`）。

## 构建

```bash
# win-x64（MSVC，/MT 静态 CRT）
cl /nologo /O2 /std:c++17 /EHsc /MT /DCCTV_H5E_CLI /Fe:cctv-h5e-win.exe cctv_h5e_decrypt.cpp
# linux-x64 / linux-arm64（zig 交叉，musl 全静态）
zig c++ -std=c++17 -O2 -s -target x86_64-linux-musl  -DCCTV_H5E_CLI -o cctv-h5e-linux-x64   cctv_h5e_decrypt.cpp
zig c++ -std=c++17 -O2 -s -target aarch64-linux-musl -DCCTV_H5E_CLI -o cctv-h5e-linux-arm64 cctv_h5e_decrypt.cpp
```

## HTTP 接口（默认 127.0.0.1:7796，env PORT）

| 端点 | 说明 |
|---|---|
| `GET /health` | 存活 + 二进制就绪检查 |
| `GET /resolve?guid=<cntv guid>` | 点播：视频信息 → hls_h5e_url，返回可播 `/m3u8` 地址 |
| `GET /m3u8?url=<h5e m3u8>&base=<enc回调前缀>` | master 重写 variant 行 / media 重写 ts 行；不传 base 时行指向本服务 |
| `GET /ts?u=<ts url>` | 拉分片；URL 含 `/h5e/` 或 `cdrm` 时解密返回，否则透传（仅补 UA）。解密前自动探测视频 PID（`--pid` 传给二进制） |
| `GET /live/channels` | 直播：内置频道清单（cctv1~17，含名称与 m3u8 路径） |
| `GET /live/m3u8?ch=cctv1&q=td&base=<enc回调前缀>` | 直播：auth-key 调 v3 接口 → hls_cdrm master → 选档（pd/td/ud/hd/md，缺省 td）→ 重写 ts 行 |

请求 cntv 一律带 `User-Agent: Lavf/60.10.100` + `Referer: https://tv.cctv.com/`（CDN 按 UA 放行，浏览器 UA 会 403）。
点播加密为 h5e 新模式（type25 使能），直播 cdrm 为 classic TEA 模式——同一解密器自动适配。
目标域名白名单：央视系 + 直播 CDN（`*.kcdnvip.com *.volcfcdn.com *.bdydns.com *.myqcloud.com *.wscdns.com *.myalicdn.com` 等，SSRF 防护）。

## drpyS 源对接

- 点播：源 play() 把 `hls_h5e_url` 包成主服务 `/proxy/<源名>/?do=h5e&u=<enc(地址)>`；源 proxy_rule 转发本插件。
- 直播：源 lazy 拼 `/proxy/<源名>/?do=live&ch=<频道>`；源 proxy_rule 转发 `/live/m3u8?ch=<频道>&base=<enc(/proxy回调前缀)>`，ts 行回流主服务（客户端只访问主服务端口，插件仅 127.0.0.1 通信）。
- 示例见 `spider/js/央视频.js`（含「直播」分类与 17 频道入口）。


## 直播行为说明（v1.1.1）

- 直播 media m3u8 重写时**丢弃列表头部第 1 个分片**（切片器刚写入的半截切片概率最高，非 IDR 对齐会导致起播花屏），起播延迟增加一个切片周期（≤4 秒）换取稳定起播；
- 单分片列表不丢弃；
- 播放器起播瞬间可能仍有 1-2 秒黑屏/花屏（等首个关键帧），属直播流固有现象。
